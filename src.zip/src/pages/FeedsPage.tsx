import { IonContent,IonRow,IonSearchbar,IonButtons,IonCard,IonCardContent,IonCardHeader,IonCardSubtitle,IonCardTitle, IonHeader, IonPage, IonTitle, IonToolbar, IonButton, IonIcon, IonLabel, IonBadge, IonCol } from '@ionic/react';
import React, { useState } from 'react';
import ExploreContainer from '../components/ExploreContainer';
import './FeedsPage.css';
import {shareSocialOutline,settings,logoElectron,searchOutline,heart,search} from 'ionicons/icons';
import { Redirect } from 'react-router';

const Feeds: React.FC = () => {
    const [searchText, setSearchText] = useState('');
  return (
    <IonPage>
      <IonContent fullscreen>
      <IonToolbar>
        <IonRow>
            <IonCol>
                <IonButton href="/feeds" fill="clear">
                    <IonIcon size="large" icon={logoElectron}/>
                    <IonLabel>Janta App</IonLabel>
                </IonButton>
            </IonCol>
            <IonButton href="/category" class="settings-btn" fill="clear"><IonIcon icon={settings}/></IonButton>
        </IonRow>


      </IonToolbar>
      
      <IonCard class="feeds">
            <img src="assets/img/1.jpeg"/>
            <IonCardHeader>
                <IonCardSubtitle color="primary">Date:1/06/2022</IonCardSubtitle>
                <IonCardTitle color="dark">Sidhu Moose Wala Cremated At His Homeland In Punjab’s Mansa District</IonCardTitle>
            </IonCardHeader>

            <IonCardContent>
                Sidhu Moosewala Cremation: The family of the 28 years old singer wanted his last rituals to take place on the ancestral farmland in the Moosa village in the Mansa region.
                <IonCardSubtitle color="primary">Category: Current Affairs</IonCardSubtitle>
            </IonCardContent>
            
            <IonButton fill="clear">
                <IonIcon color="dark"icon={shareSocialOutline}/>
            </IonButton>
            <IonButton fill="clear">
                <IonIcon color="danger" icon={heart}/><IonBadge color="light">6</IonBadge>
            </IonButton>
        </IonCard>

        <IonCard class="feeds">
            <IonCardHeader>
                <IonCardSubtitle color="primary">Date:1/06/2022</IonCardSubtitle>
                <IonCardTitle color="dark">Sidhu Moose Wala Cremated At His Homeland In Punjab’s Mansa District</IonCardTitle>
            </IonCardHeader>

            <IonCardContent>
                Sidhu Moosewala Cremation: The family of the 28 years old singer wanted his last rituals to take place on the ancestral farmland in the Moosa village in the Mansa region.
                <IonCardSubtitle color="primary">Category: Current Affairs</IonCardSubtitle>
            </IonCardContent>
            
            <IonButton fill="clear">
                <IonIcon color="dark"icon={shareSocialOutline}/>
            </IonButton>
            <IonButton fill="clear">
                <IonIcon color="danger" icon={heart}/><IonBadge color="light">6</IonBadge>
            </IonButton>
        </IonCard>
      </IonContent>
    </IonPage>
  );
};

export default Feeds;
