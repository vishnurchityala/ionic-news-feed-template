import { IonRow,IonCard,IonCol,IonCardContent,IonCardHeader,IonButton,IonIcon,IonLabel,IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonImg, IonBadge, IonCheckbox, IonCardTitle, IonItemDivider, IonCardSubtitle } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import './CategoriesPage.css';
import {logoElectron,settings} from 'ionicons/icons'
type Item = {
    src: any;
    text: string;
  };
const images: Item[] = [{ src: '/assets/img/1.jpeg', text: 'a picture of a cat' }];
const Categories: React.FC = () => {
  return (
    <IonPage>
      <IonToolbar>
        <IonRow>
            <IonCol>
                <IonButton href="/feeds" fill="clear">
                    <IonIcon size="large" icon={logoElectron}/>
                    <IonLabel>Janta App</IonLabel>
                </IonButton>
            </IonCol>
            <IonButton href="/category" class="settings-btn" fill="clear"><IonIcon icon={settings}/></IonButton>
        </IonRow>
      </IonToolbar>
      <IonContent fullscreen>
      <IonCard>
        <IonCardHeader>
          <img src="assets/img/Tech.jpeg"/>
          <IonCardTitle>
            Tech
          </IonCardTitle>
        </IonCardHeader>
        <IonCardContent>
          This category consist news feed related to Technology, upcoming Tech products and thier progress
          <IonItemDivider/>
          <IonCardSubtitle><IonCheckbox color="primary"></IonCheckbox><IonBadge color="light">Select</IonBadge></IonCardSubtitle>
        </IonCardContent>
        
      </IonCard>
      <IonCard>
        <IonCardHeader>
          <img src="assets/img/Worldaffair.png"/>
          <IonCardTitle>
            World Affairs
          </IonCardTitle>
        </IonCardHeader>
        <IonCardContent>
          This category consist of news feed related to world affairs.
          <IonItemDivider/>
          <IonCardSubtitle><IonCheckbox color="primary"></IonCheckbox><IonBadge color="light">Select</IonBadge></IonCardSubtitle>
        </IonCardContent>
      </IonCard>
      <IonCard>
        <IonCardHeader>
          <img src="assets/img/CurrentEvent.jpeg"/>
          <IonCardTitle>
            Current Events
          </IonCardTitle>
        </IonCardHeader>
        <IonCardContent>
        This category consist news feed related to Current affairs in country and
          this is the default category.
          <IonItemDivider/>
          <IonCardSubtitle><IonCheckbox color="primary"></IonCheckbox><IonBadge color="light">Select</IonBadge></IonCardSubtitle>
        </IonCardContent>
      </IonCard>
      <IonCard>
        <IonCardHeader>
          <img src="assets/img/Movie.jpeg"/>
          <IonCardTitle>
            Movies And Entertainement
          </IonCardTitle>
        </IonCardHeader>
        <IonCardContent>
            This category is for updates related to upcoming movies and thier collection worldwide.
          <IonItemDivider/>
          <IonCardSubtitle><IonCheckbox color="primary"></IonCheckbox><IonBadge color="light">Select</IonBadge></IonCardSubtitle>
        </IonCardContent>
      </IonCard>
      </IonContent>
    </IonPage>
  );
};

export default Categories;
