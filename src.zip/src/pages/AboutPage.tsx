import { IonList,IonItem, IonButton,IonIcon,IonImg, IonContent, IonCard,IonCardContent,IonCardHeader,IonCardSubtitle,IonCardTitle ,IonHeader, IonPage, IonTitle, IonToolbar, IonLabel } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import './AboutPage.css';
import { logoIonic, camera,logoReact,serverOutline,codeDownloadOutline ,codeSlashOutline, shareSocialOutline,settings,logoElectron,searchOutline,heart,search} from 'ionicons/icons';
import { Camera, CameraResultType } from '@capacitor/camera';

const About: React.FC = () => {
  return (
    <IonPage>
      <IonContent fullscreen>
        <IonButton href="/feeds" class="profile" color="primary" fill="clear">
        <IonIcon  icon={logoElectron}  class="profile1" />
        </IonButton>
        <div className="about-text">
        <IonCardHeader>
          <IonCardTitle color="dark">About App ?</IonCardTitle>
        </IonCardHeader>

        <IonCardContent>
          <IonLabel color="dark">This app is created for providing a clean and hygiene environement for students and editors to know important things around and also to share things with world.</IonLabel>
          <IonCardSubtitle color="primary">Creator: Vishnu r chityala</IonCardSubtitle>
        </IonCardContent>
        </div>
  
        
       <IonCard>
            <IonItem>
              <IonIcon color="primary" icon={codeSlashOutline}/><IonLabel color="primary"> Technology used</IonLabel>
            </IonItem>
            <IonItem>
              <IonLabel>IONIC</IonLabel><IonIcon color="primary" icon={logoIonic}/>
            </IonItem>
            <IonItem>
              <IonLabel>REACT</IonLabel> <IonIcon color="primary" icon={logoReact}/>
            </IonItem>
            <IonItem>
              <IonLabel>SQL</IonLabel> <IonIcon color="primary" icon={serverOutline}/>
            </IonItem>
            <IonItem>
              <IonLabel>Express</IonLabel> <IonIcon color="primary" icon={codeDownloadOutline}/>
            </IonItem>
        </IonCard> 
      </IonContent>
    </IonPage>
  );
};

export default About;
