import { IonButton, IonRow,IonCol,IonCardHeader,IonItem,IonCardSubtitle,IonBadge,IonCardContent,IonCardTitle,IonIcon,IonContent, IonHeader, IonImg, IonLabel, IonPage, IonTitle, IonToolbar, IonCard, IonInput, IonTextarea, IonSelect, IonSelectOption } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import './AddFeedsPage.css';
import takepicture from './Camera';
import {camera,logoElectron,settings,share,shareSocialOutline,heart} from "ionicons/icons";
import { Camera, CameraResultType } from '@capacitor/camera';
import * as ReactDOMServer from 'react-dom/server';
import { useState } from 'react';
import { Share } from '@capacitor/share';

type Item = {
  src: any;
  text: string;
};

const images: Item[] = [{ src: '/assets/img/1.jpeg', text: 'a picture of a cat' }];




const AddFeeds: React.FC = () => {
  
  const [image,setImage] =  useState<any>("");
  const takePicture = async () => {
    const cameraResult = await Camera.getPhoto({
      quality: 90,
      allowEditing: true,
      resultType: CameraResultType.Uri
    });
  
    // image.webPath will contain a path that can be set as an image src.
    // You can access the original file using image.path, which can be
    // passed to the Filesystem API to read the raw data of the image,
    // if desired (or pass resultType: CameraResultType.Base64 to getPhoto)
    setImage(cameraResult.webPath);
  
  
    // Can be set to the src of an image now <IonButton onClick={shareImg}><IonIcon icon={share} /><IonLabel>Share</IonLabel></IonButton>
    console.log(image);
  };
  

  
  const shareImg = async () => {
    await Share.share({
    title: 'See cool stuff',
    text: 'Really awesome thing you need to see right meow',
    url: image,
    dialogTitle: 'Share with buddies',
  });}

  return (
    <IonPage>
      <IonToolbar>
        <IonRow>
            <IonCol>
                <IonButton href="/feeds" fill="clear">
                    <IonIcon size="large" icon={logoElectron}/>
                    <IonLabel>Janta App</IonLabel>
                </IonButton>
            </IonCol>
            <IonButton href="/category" class="settings-btn" fill="clear"><IonIcon icon={settings}/></IonButton>
        </IonRow>
      </IonToolbar>
      <IonContent>
        
      <IonCard>
            <IonImg  src={image}></IonImg> 
            <IonButton expand="full"  onClick={takePicture} fill="clear" color="danger"><IonLabel>upload photo</IonLabel></IonButton>
            <IonCardHeader>
                <IonCardTitle color="primary">Date:</IonCardTitle>
                <IonItem><IonInput type="date"></IonInput></IonItem>
                <IonCardTitle color="primary">Title:</IonCardTitle>
                <IonItem><IonTextarea placeholder="Please type title here"></IonTextarea></IonItem>
            </IonCardHeader>

            <IonCardContent>
                <IonCardTitle color="primary">Content:</IonCardTitle>
                <IonItem><IonTextarea placeholder="Please type your content here"></IonTextarea></IonItem>
                <IonCardTitle color="primary">Category:</IonCardTitle>
                <IonItem>
                <IonSelect>
                  <IonSelectOption>Tech</IonSelectOption>
                  <IonSelectOption>Current Affairs</IonSelectOption>
                  <IonSelectOption>World Affairs</IonSelectOption>
                  <IonSelectOption>Movies and Entertainement</IonSelectOption>
                  
                </IonSelect>
                </IonItem>
                
            </IonCardContent>  
            <IonButton expand="full" color="success" fill="clear">Upload Feed</IonButton>         
            
      
      </IonCard>
      </IonContent>
    </IonPage>
  );
};

export default AddFeeds;
