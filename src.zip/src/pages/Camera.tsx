import { IonButton, IonContent, IonCard,IonHeader, IonIcon, IonPage, IonLabel,IonTitle, IonToolbar, IonImg, IonCardTitle } from '@ionic/react';
import ExploreContainer from '../components/ExploreContainer';
import './Camera.css';

const takepicture: React.FC = () => {
  return (
    <IonPage>
      <IonContent fullscreen>
          <IonCard>
              <IonImg></IonImg>
              <IonCardTitle>give image</IonCardTitle>
              <IonButton><IonLabel>upload</IonLabel></IonButton>
          </IonCard>
      </IonContent>
    </IonPage>
  );
};

export default takepicture;
